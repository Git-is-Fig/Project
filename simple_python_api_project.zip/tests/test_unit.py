def test_basic_math():
    assert 2 + 2 == 4